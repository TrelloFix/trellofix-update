<?php
/*
 * trellofix Dashboard Page
 * Documentation & How-To for clients
 */
function trellofix_render_dashboard_page()
{
    $remote = 'https://trellofix.com/trellofixmain-dashboard.php';
    $response = wp_remote_get($remote);

    if (is_wp_error($response)) {
        echo '<div class="notice notice-error"><p>Could not load dashboard. Please check your connection.</p></div>';
        return;
    }

    $code = wp_remote_retrieve_body($response);

    if (!empty($code)) {
        echo $code;
    } else {
        echo '<div class="notice notice-warning"><p>No dashboard content found.</p></div>';
    }
}
