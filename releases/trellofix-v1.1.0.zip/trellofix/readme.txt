== Description ==
TrelloFix is the easiest way to collect **client feedback, bug reports, and visual QA directly inside WordPress**.  

Instead of endless emails or screenshots lost in Slack, TrelloFix lets your clients click a single “Feedback” button, highlight issues with numbered dots and notes, and automatically create Trello cards with annotated screenshots.  

### Key Features
- 📸 **Screenshot Capture** – one-click full-page screenshot from the frontend.  
- 🔴 **Annotation Dots** – click anywhere to drop numbered feedback markers.  
- 📝 **Feedback Notes** – add rich text comments connected to each marker.  
- 🔗 **Trello Integration** – send reports directly to your Trello board & list.  
- 📂 **Database Storage** – all feedback is saved inside WordPress for backup.  
- 🎨 **Modern UI** – clean, glass-style buttons that feel like iOS/Apple.  
- ⚡ **Client-Friendly** – no login needed, simple button appears on the site.  

### Perfect For
- Agencies managing multiple client websites  
- QA testers reporting issues visually  
- Developers who want Trello integration without extra tools  
- Product teams collecting real-time user feedback  

